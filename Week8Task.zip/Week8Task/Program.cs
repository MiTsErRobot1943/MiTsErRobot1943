﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week8Task
{
    class Program
    {
        static void Main(string[] args)
        {
            BasePlusCommissionEmployeec baseEmployee = new BasePlusCommissionEmployeec("Bob", "Lewis", "33-33-33", 5000.00M, 0.04M, 300.00M);

            Console.WriteLine("Base Plus Commission Employee information obtained by properties and methods: \n");

            // Comments below 

            Console.WriteLine("First name is {0}", baseEmployee.FirstName, "\n");
            Console.WriteLine("Last name is {0}", baseEmployee.LastName, "\n");
            Console.WriteLine("Social Security Number is {0}", baseEmployee.SocialSecurityNumber, "\n");
            Console.WriteLine("Gross Sales are : {0:C}", baseEmployee.GrossSales, "\n");
            Console.WriteLine("Commission Rate is : {0:F2}", baseEmployee.CommissionRate, "\n");
            Console.WriteLine("Base Salary is :{0:C}", baseEmployee.BaseSalary, "\n");
            Console.WriteLine("Earnings are :  {0:C}", baseEmployee.Earning());

            baseEmployee.BaseSalary = 1000.00M;

            Console.WriteLine("\n{0}: \n\n{1}", "Updated employee information obtained by ToString", baseEmployee);

            Console.WriteLine("earnings:  {0:C}", baseEmployee.Earning());
            Console.ReadKey();
        }
    }
}