﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Week8Task
{
    class BasePlusCommissionEmployeec : CommissionEmployees
    {
        private decimal baseSalary;

       public BasePlusCommissionEmployeec (string first, string last, string ssn, decimal sales, decimal rate, decimal salary) : base (first, last, ssn, sales, rate) 
       {
            BaseSalary = salary;
       }

        public decimal BaseSalary { // Getting/setting the base salary for properties 
            get
            { return baseSalary; }
            set {
                if (value >= 0)
                    baseSalary = value;

                else
                    throw new ArgumentOutOfRangeException("Gross sales ", value, "GrossSales must be >= 0");
            }
        }

        public override decimal Earning()
       {
            //decimal result = commissionRate * grossSales;
            //decimal BS = 0;
            return baseSalary + base.Earning();
        }

        public override string ToString()
        {
            //Comments below are the mistakes I've made and have fixed!!!

            //return string.Format(
            //"{0}: {1} {2}\n{3}: {4}\n{5}: {6:C}\n{7}: {8:F2}",
            //"Commission employee", FirstName, LastName,
            //"social security number", SocialSecurityNumber,
            //"gross sales", GrossSales, "commission rate", CommissionRate);
            return string.Format("base salaried {0}\n base salary: {1:C}",
            base.ToString(), BaseSalary);
        }

    }
}
