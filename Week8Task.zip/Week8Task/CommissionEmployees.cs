﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Week8Task
{
    public class CommissionEmployees
    {
        private string firstName;
        private string lastName;
        private string socialSecurityNumber;
        private decimal grossSales;
        private decimal commissionRate;

        public CommissionEmployees(string first, string last, string ssn, decimal sales, decimal rate)
        {
            firstName = first;
            lastName = last;
            socialSecurityNumber = ssn;
            grossSales = sales;
            commissionRate = rate;
        }
        public string FirstName // Specifies the properties of the variable 
        //WRITE THE INSTANCE OF VARIABLE AS WRITEN HERE 
        {
            get { return firstName; } 
        }

        public string LastName // Specifies the properties of the variable 
        {
            get
            {
                return lastName;
            }
            
        }

        public string SocialSecurityNumber // Specifies the properties of the variable 
        {
            get
            {
                return socialSecurityNumber;
            }
            
        }

        public decimal GrossSales
        {
            get
            {
                return grossSales;
            }
            set
            {
                if(value >= 0)
                {
                    grossSales = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Gross sales ", value, "GrossSales must be >= 0");
                }
            }
        }

        public decimal CommissionRate // remember to make the name slightly different 
        {
            get
            {
                return commissionRate;
            }
            set
            {
               if (value > 0 && value < 1)
                {
                    commissionRate = value;
                }
               else
                {
                    throw new ArgumentOutOfRangeException("Commission rate must be > 0 and < 1");
                }
            }

        }
           public virtual decimal Earning() 
        {
            decimal result = commissionRate * grossSales;

            return result;
        }

        public override string ToString() // change this from override to virtual so stuff is accessible in child class 
        {
            return string.Format(
            "{0}: {1} {2}\n{3}: {4}\n{5}: {6:C}\n{7}: {8:F2}",
            "Commission employee", FirstName, LastName, 
            "social security number", SocialSecurityNumber,
            "gross sales", GrossSales, "commission rate", CommissionRate);
        }

    }
}
